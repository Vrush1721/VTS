﻿namespace VTS.Models
{
    public class Response
    {
        public int statusCode { get; set; }
        public String statusMessage { get; set; }
    }
}
