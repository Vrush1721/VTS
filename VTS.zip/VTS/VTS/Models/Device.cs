﻿namespace VTS.Models
{
    public class Device
    {
        public int DeviceID { get; set; }
        public required string DeviceName { get; set; }
        public required string DeviceType { get; set; }
      
    }
}
