﻿namespace VTS.Models
{
    public class UserMaster
    {
        public int UserID { get; set; }
        public required string Name { get; set; }
        public required string Mobile { get; set; }
        public required string Organization { get; set; }
        public required string Address { get; set; }
        public required string Email { get; set; }
        public required string Location { get; set; }
        public required string PhotoPath { get; set; }

    }
}
