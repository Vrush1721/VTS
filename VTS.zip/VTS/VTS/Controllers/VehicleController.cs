﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using VTS.Models;

namespace VTS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public VehicleController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // POST: api/UserMaster/registerUser
        [HttpPost]
        [Route("addVehicle")]
        public string addVehicle(Vehicle vehicle)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("VTS").ToString());
            SqlCommand cmd = new SqlCommand("INSERT INTO dbo.User_Vehicle " +
                                           "(VehicleNumber, VehicleType, ChassisNumber, EngineNumber, ManufacturingYear, " +
                                           "LoadCarryingCapacity, Make, Model, BodyType, OrganisationName, DeviceID, UserID) " +
                                           "VALUES ('"+vehicle.VehicleNumber+ "','"+vehicle.VehicleType+"','"+vehicle.ChassisNumber+"','"+vehicle.EngineNumber+"', '"+ vehicle.ManufacturingYear+"', " +
                                           "+'"+ vehicle.LoadCarryingCapacity+"','"+ vehicle.Make+"','"+vehicle.Model+ "','"+vehicle.BodyType+"','"+vehicle.OrganisationName + "','"+vehicle.DeviceID +"','"+vehicle.UserID+"')", con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                return "Vehicle Save successfully!";
            }
            else
            {
                return "Error: Vehicle registration failed.";
            }
        }






        // PUT: api/Vehicle/updateVehicle/{id}
        [HttpPut]
        [Route("updateVehicle/{id}")]
        public string updateVehicle(String id, Vehicle vehicle)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("VTS").ToString());
            SqlCommand cmd = new SqlCommand("UPDATE dbo.User_Vehicle " +
                                           "SET VehicleType = @VehicleType, ChassisNumber = @ChassisNumber, EngineNumber = @EngineNumber, " +
                                           "ManufacturingYear = @ManufacturingYear, LoadCarryingCapacity = @LoadCarryingCapacity, Make = @Make, " +
                                           "Model = @Model, BodyType = @BodyType, OrganisationName = @OrganisationName, DeviceID = @DeviceID, UserID = @UserID " +
                                           "WHERE VehicleNumber = @VehicleNumber", con);

            // Add parameters to avoid SQL Injection
            // cmd.Parameters.AddWithValue("@VehicleNumber", vehicle.VehicleNumber);  // VehicleNumber as string (nvarchar)
            cmd.Parameters.AddWithValue("@VehicleNumber", id);  // For identifying the vehicle to update
            cmd.Parameters.AddWithValue("@VehicleType", vehicle.VehicleType);
            cmd.Parameters.AddWithValue("@ChassisNumber", vehicle.ChassisNumber);
            cmd.Parameters.AddWithValue("@EngineNumber", vehicle.EngineNumber);
            cmd.Parameters.AddWithValue("@ManufacturingYear", vehicle.ManufacturingYear);
            cmd.Parameters.AddWithValue("@LoadCarryingCapacity", vehicle.LoadCarryingCapacity);
            cmd.Parameters.AddWithValue("@Make", vehicle.Make);
            cmd.Parameters.AddWithValue("@Model", vehicle.Model);
            cmd.Parameters.AddWithValue("@BodyType", vehicle.BodyType);
            cmd.Parameters.AddWithValue("@OrganisationName", vehicle.OrganisationName);
            cmd.Parameters.AddWithValue("@DeviceID", vehicle.DeviceID);
            cmd.Parameters.AddWithValue("@UserID", vehicle.UserID);
           

            try
            {
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();

                if (i > 0)
                {
                    return "Vehicle updated successfully!";
                }
                else
                {
                    return "Error: Vehicle update failed. Please check if the user exists.";
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }




        // GET: api/Vehicle/searchVehicles
        [HttpGet]
        [Route("searchVehicles")]
        public async Task<IActionResult> SearchVehicles(string vehicleNumber = "", string vehicleType = "", string chassisNumber = "", string make = "", int pageNumber = 1, int pageSize = 10)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("VTS").ToString());

            // Define the SQL query with wildcards for searching
            string query = @"
                SELECT VehicleNumber, VehicleType, ChassisNumber, EngineNumber, ManufacturingYear, LoadCarryingCapacity, 
                       Make, Model, BodyType, OrganisationName, DeviceID, UserID
                FROM dbo.User_Vehicle
                WHERE (VehicleNumber LIKE @VehicleNumber)
                  AND (VehicleType LIKE @VehicleType)
                  AND (ChassisNumber LIKE @ChassisNumber)
                  AND (Make LIKE @Make)
                ORDER BY VehicleNumber
                OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;
            ";

            // Define the SQL parameters with the provided search criteria
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@VehicleNumber", "%" + vehicleNumber + "%");
            cmd.Parameters.AddWithValue("@VehicleType", "%" + vehicleType + "%");
            cmd.Parameters.AddWithValue("@ChassisNumber", "%" + chassisNumber + "%");
            cmd.Parameters.AddWithValue("@Make", "%" + make + "%");

            // Implement pagination
            cmd.Parameters.AddWithValue("@Offset", (pageNumber - 1) * pageSize);
            cmd.Parameters.AddWithValue("@PageSize", pageSize);

            try
            {
                con.Open();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();
                List<Vehicle> vehicles = new List<Vehicle>();

                // Read results
                while (await reader.ReadAsync())
                {
                    vehicles.Add(new Vehicle
                    {
                        VehicleNumber = reader["VehicleNumber"].ToString(),
                        VehicleType = reader["VehicleType"].ToString(),
                        ChassisNumber = reader["ChassisNumber"].ToString(),
                        EngineNumber = reader["EngineNumber"].ToString(),
                        ManufacturingYear = Convert.ToInt32(reader["ManufacturingYear"]),
                        LoadCarryingCapacity = Convert.ToDecimal(reader["LoadCarryingCapacity"]),
                        Make = reader["Make"].ToString(),
                        Model = reader["Model"].ToString(),
                        BodyType = reader["BodyType"].ToString(),
                        OrganisationName = reader["OrganisationName"].ToString(),
                        DeviceID = Convert.ToInt32(reader["DeviceID"]),
                        UserID = Convert.ToInt32(reader["UserID"])
                    });
                }

                con.Close();

                return Ok(vehicles);
            }
            catch (Exception ex)
            {
                return BadRequest("Error: " + ex.Message);
            }
        }


    }
}
