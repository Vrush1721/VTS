﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VTS.Models;
using Microsoft.Data.SqlClient;

namespace VTS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DeviceController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public DeviceController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // POST: api/UserMaster/registerUser
        [HttpPost]
        [Route("addDevice")]
        public string addDevice(Device device)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("VTS").ToString());
            SqlCommand cmd = new SqlCommand("INSERT INTO dbo.Device (DeviceName, DeviceType) " +
                       "VALUES ('" + device.DeviceName + "', '" + device.DeviceType + "')", con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                return "Device Added successfully!";
            }
            else
            {
                return "Error: Adding device failed.";
            }
        }
    }
}
