﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using VTS.Models;

namespace VTS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserMasterController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public UserMasterController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // POST: api/UserMaster/registerUser
        [HttpPost]
        [Route("registerUser")]
        public string registerUSer(UserMaster userMaster)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("VTS").ToString());
            SqlCommand cmd = new SqlCommand("INSERT INTO dbo.User_Master (Name, MobileNumber, Organozation, Address, Email, Location, Photopath) " +
                       "VALUES ('" + userMaster.Name + "', '" + userMaster.Mobile + "', '" + userMaster.Organization + "', '" +
                       userMaster.Address + "', '" + userMaster.Email + "', '" + userMaster.Location + "', '" + userMaster.PhotoPath + "')", con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                return "User registered successfully!";
            }
            else
            {
                return "Error: User registration failed.";
            }
        }

        // PUT: api/UserMaster/updateUser/{id}
        [HttpPut]
        [Route("updateUser/{id}")]
        public string updateUser(int id, UserMaster userMaster)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("VTS").ToString());
            SqlCommand cmd = new SqlCommand("UPDATE dbo.User_Master " +
                                           "SET Name = @Name, MobileNumber = @MobileNumber, Organozation = @Organozation, " +
                                           "Address = @Address, Email = @Email, Location = @Location, Photopath = @Photopath " +
                                           "WHERE UserID = @UserID", con);

            // Add parameters to avoid SQL injection
            cmd.Parameters.AddWithValue("@Name", userMaster.Name);
            cmd.Parameters.AddWithValue("@MobileNumber", userMaster.Mobile);
            cmd.Parameters.AddWithValue("@Organozation", userMaster.Organization);
            cmd.Parameters.AddWithValue("@Address", userMaster.Address);
            cmd.Parameters.AddWithValue("@Email", userMaster.Email);
            cmd.Parameters.AddWithValue("@Location", userMaster.Location);
            cmd.Parameters.AddWithValue("@Photopath", userMaster.PhotoPath);
            cmd.Parameters.AddWithValue("@UserID", id);

            try
            {
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();

                if (i > 0)
                {
                    return "User updated successfully!";
                }
                else
                {
                    return "Error: User update failed. Please check if the user exists.";
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }
    }
}
